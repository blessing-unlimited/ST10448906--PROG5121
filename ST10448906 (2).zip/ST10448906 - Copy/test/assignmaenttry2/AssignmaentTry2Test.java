/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/UnitTests/JUnit4TestClass.java to edit this template
 */
package assignmaenttry2;

import javax.swing.JOptionPane;
import org.junit.Test;
import static org.junit.Assert.*;

/**
 *
 * @author Ricardo
 */
public class AssignmaentTry2Test {
    
    public AssignmaentTry2Test() {
    }

    @Test
    public void testSomeMethod() {
        
        login2 obj = new login2("","","kyl_l","CH&&sec@ke99","",""); //(Farrel,2023)
        boolean expected = true;
       
        boolean actualResult = obj.checkUsername();
        assertEquals(expected, actualResult);
        
        boolean expectedPassword = true;
        
        boolean passwordResult = obj.checkPasswordComplexity();
        assertEquals(expectedPassword,passwordResult);
        
        boolean expectedLogin = true;
        boolean loginResult = obj.loginUser();
        assertEquals(expectedLogin,loginResult);
        
        //Part 2 
        
        Task task = new Task("","AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA","","","",0,0,0);//(Farrel,2023)
        
        Task task1 = new Task("","Create Login to authenticate users","","","",0,0,0);//(Farrel,2023)
        
        boolean expectedCheckTest1 = true;
        boolean checkResult = task.checkTaskDescrip();
        assertEquals(expectedCheckTest1,checkResult);
        
        boolean expectedCheckTest2 = false;
        boolean checkResult2 = task1.checkTaskDescrip();
        assertEquals(expectedCheckTest2,checkResult2);
        
        Task task2 = new Task("Add Login Feature","","","Robyn","",0,0,0);//(Farrel,2023)
        
        String expectedTaskID = "AD:0:BYN";
        String checkTaskID = task2.createTaskID();
        assertEquals(expectedTaskID,checkTaskID);
        
        Task task3 = new Task("","","","","",0,0,0);
        Task tasks[] = new Task[5];
        
        for(int a = 0; a < tasks.length; a++){
            int duration = Integer.parseInt(JOptionPane.showInputDialog("Enter duration."));//(Farrel,2023)
            
            Task task4 = new Task("","","","","",0,duration,0);
            tasks[a] = task4;
        }
        
        int expectedReturn = 89;
        
        int checkReturn = task3.returnTotalHours(tasks);
        assertEquals(expectedReturn,checkReturn);        
    }
    
}
