package assignmaenttry2;

import javax.swing.JOptionPane;

public class login2 {
        
        private String name ,lastName ,username,password,loginUsername,loginPassword;
        
        public login2(){
           name = lastName = username = password = loginUsername = loginPassword = null;
        }
        public login2(String name, String lastName ,String username ,String password ,String loginUsername ,String loginPassword){
            this.name = name;
            this.lastName = lastName;
            this.username = username;
            this.password = password;
            this.loginUsername = loginUsername;
            this.loginPassword = loginPassword;
        }
        
                public void setName(String n){
                    name = n;
                }
                public String getName(){
                    return name;
                }
                public void setLastName(String l){
                    lastName = l;
                }
                public String getLastName(){
                    return lastName;
                }
                public void setUsername(String u){
                    username = u;
                }
                public String getUsername(){
                    return username;
                }
                public void setPassword(String p){
                    password = p;
                }
                public String getPassword(){
                    return password;
                }
                public void setLoginUsername(String u){
                    loginUsername = u;
                }
                public String getLoginUsername(){
                    return loginUsername;
                }
                public void setLoginPassword(String l){
                    loginPassword = l;
                }
                public String getLoginPassword(){
                    return loginPassword;
                }
                    public boolean checkUsername(){ //(Farrel,2023)
                        
                        boolean usernameComplexity = false;
                        
                            if(username.length() <= 5 && username.contains("_") && !username.isBlank())
                                usernameComplexity = true;
                             
                        return usernameComplexity;
                    }
                    
                    public boolean checkPasswordComplexity(){
                        
                        boolean hasDigit = false;
                        boolean hasCapital = false;
                        boolean hasSpecial = false;
                        
                            if(password.length() >= 8 && !username.isBlank()){
                                
                                for(int x = 0; x < password.length();x++){
                                    
                                    char c = password.charAt(x);
                                        
                                        if(Character.isDigit(c)){
                                            hasDigit = true;
                                        }
                                        else if(Character.isUpperCase(c)){
                                            hasCapital = true;
                                        }
                                        else if(!Character.isLetterOrDigit(c)){
                                            hasSpecial = true;
                                        }
                                    }
                            }
                            else{
                                return false;
                            }    
                        return hasDigit && hasCapital && hasSpecial;
                    }
                    
                    public void registerUser(){
                        
                        while(true){    //(Nurul,2017)
                        
                            username = JOptionPane.showInputDialog("Create a username(must contain an underscore and must be no longer than 5 characters).");//(Farrel,2023)
                                
                                if(checkUsername()){ //(Farrel,2023)
                                    JOptionPane.showMessageDialog(null, "Username successfully captured.");//(Farrel,2023)
                                        break;
                                }
                                else{
                                    JOptionPane.showMessageDialog(null,"Username is not formatted correctly, please ensure that username conatins an underscore and is no longer than 5 characters.","Incorrect username",JOptionPane.ERROR_MESSAGE);//(Farrel,2023)
                                }
                        }
                        
                        while(true){    //(Nurul,2017)
                            
                            password = JOptionPane.showInputDialog("Create a password(must contain a Captital letter , a digit, special character ,and must be at least 8 characters long).");
                            
                            if(checkPasswordComplexity()){ //(Farrel,2023)
                                JOptionPane.showMessageDialog(null, "Password successfully captured.");
                                    break;
                            }
                            else{
                                JOptionPane.showMessageDialog(null, "Password is not correctly formated, please ensure that your password conatins a capital letter, a number, a special character and is at least 8 characters long.","Incorrect password",JOptionPane.ERROR_MESSAGE);
                            }
                        }
                        
                    }
                   
                    public boolean loginUser(){
                        
                        loginUsername = JOptionPane.showInputDialog("Enter your username.");//(Farrel,2023)
                        loginPassword = JOptionPane.showInputDialog("Enter your password.");
                            
                            if(loginPassword.equals(password) && loginUsername.equals(username) && !loginPassword.isBlank() && !loginUsername.isBlank()){
                                return true;
                            }
                            else{
                                return false;
                            }
                        
                    }
                    
                    public String returnLoginStatus(){
                        
                        while(true){ //(Nurul,2017)
                            if(loginUser()){ //(Farrel,2023)
                                JOptionPane.showMessageDialog(null, "Welcome " + name + "," + lastName + " it's great to see you again.");
                                return "Login Successful.";
                            }
                            else{
                                JOptionPane.showMessageDialog(null, "Username or password incorrect, try again.","Login",JOptionPane.ERROR_MESSAGE);
                            }
                        }    
                        
                    }

}
