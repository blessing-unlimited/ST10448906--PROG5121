package assignmaenttry2;

import javax.swing.JOptionPane;

public class Task {
    
    private String taskName,taskDescrip,taskId,developer,status;
    private int numberOfTasks,duration,taskNum;
    
    Task[] tasks = new Task[numberOfTasks];
    
        public Task(){
            taskName = taskDescrip = taskId = status ="";
            numberOfTasks = duration = taskNum = 0;
        }
        public Task(String taskName,String taskDescrip,String taskId,String developer,String status,int numberOfTasks,int duration,int taskNum){
            this.taskName = taskName;
            this.taskDescrip = taskDescrip;
            this.taskId = taskId;
            this.developer = developer;
            this.status = status;
            this.numberOfTasks = numberOfTasks;
            this.duration = duration;
            this.taskNum = taskNum;
        }
        
        public void setTaskName(String t){
            taskName = t;
        }
        public String getTaskName(){
          return taskName;
        }
        public void setTaskDescrip(String t){
            taskDescrip = t;
        }
        public String getTaskDescrip(){
            return taskDescrip;
        }
        public void setTaskID(String t){
            taskId = t;
        }
        public String getTaskId(){
            return createTaskID();
        }
        public void setStatus(String s){
            status = s;
        }
        public String getStatus(){
            return status;
        }
        public void setNumberOfTasks(int n){
            numberOfTasks = n;
        }
        public void setDuration(int d){
            duration = d;
        }
        public int getDuration(){
            return duration;
        }
        public void setTaskNum(int t){
            taskNum = t;
        }
        public int getTaskNum(){
            return taskNum;
        }
        public void setDeveloper(String d){
            developer = d;
        }
        public String getDeveloper(){
            return developer;
        }
        
        public String createTaskID(){//(Farrel,2023)
            if(taskName != null && developer != null){
            String firstTwo = taskName.substring(0, Math.min(taskName.length(), 2));
            String lastThree = developer.substring( Math.max(0,developer.length() - 3));
            
             taskId = firstTwo.toUpperCase() + ":" + taskNum + ":" + lastThree.toUpperCase();
            
             return taskId;
            }
            else{
                return "Task cannot be completed, missing information.";
            }
        }
        public boolean checkTaskDescrip(){//(Farrel,2023)
            
                    
        int count = 0;
         
        for(int x = 0; x < taskDescrip.length(); x++){
            if(!taskDescrip.isBlank()){
               count++; 
            }
        }
        
            if(count >= 50){
                return true;
            }
            else{
                return false;
            }
        }

    /**
     *
     * @param tasks
     */
    public void printTaskDetails(Task tasks[]){//(Farrel,2023)
            for(int x = 0; x < numberOfTasks; x++){
                JOptionPane.showMessageDialog(null,"Task details: " + "\nTask status: " + tasks[x].getStatus()
                                                                    + "\nDeveloper details: " + tasks[x].getDeveloper()
                                                                    + "\nTask Number: " + tasks[x].getTaskNum()
                                                                    + "\nTask Name: " + tasks[x].getTaskName()
                                                                    + "\nTask Description: " + tasks[x].getTaskDescrip()
                                                                    + "\nTask ID: " + tasks[x].getTaskId()
                                                                    + "\nTask Duration: " + tasks[x].getDuration() +" hrs."
                                                                    + "\n\nTotal hours: " + tasks[x].returnTotalHours(tasks) + "hrs");
            }
            
        }
        public int returnTotalHours(Task tasks[]){//(Farrel,2023)
            int totalHours = 0;
            
            for(int x = 0; x < tasks.length ;x++){
                totalHours += tasks[x].getDuration();
            }
            return totalHours;
        }
        
        public void menu(){//(Farrel,2023)
        
            int choice =  0;
        
            do{
            
                choice = Integer.parseInt(JOptionPane.showInputDialog("Hi, What would you like to do? \n1) Add tasks \n2) Show report \n0) Quit"));
            
                switch(choice){
                
                    case 1:
                        
                        break;
                    case 2:
                        JOptionPane.showMessageDialog(null,"Coming soon.");
                        break;
                    case 0:
                        JOptionPane.showMessageDialog(null,"You are exiting the program, thank you for using the program.");
                        break;
                    default: JOptionPane.showMessageDialog(null,"Invalid input,please try again.");
                }
            }while(choice != 0);
        }

}
