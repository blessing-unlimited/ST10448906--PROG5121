/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/UnitTests/JUnit4TestClass.java to edit this template
 */
package assignmaenttry2;

import assignmaenttry2.Task;
import javax.swing.JOptionPane;
import org.junit.Assert;
import static org.junit.Assert.assertEquals;
import org.junit.Test;

/**
 *
 * @author Ricardo
 */
public class AssignmaentTry2Test {
    
    public AssignmaentTry2Test() {
    }

    @Test
    public void testSomeMethod() {
        
        login2 obj = new login2("","","kyl_l","CH&&sec@ke99","",""); //(Farrel,2023)
        AssignmaentTry2 assign = new AssignmaentTry2();
            boolean expected = true;

            boolean actualResult = obj.checkUsername();
            assertEquals(expected, actualResult);

            boolean expectedPassword = true;

            boolean passwordResult = obj.checkPasswordComplexity();
            assertEquals(expectedPassword,passwordResult);

            boolean expectedLogin = true;
            boolean loginResult = obj.loginUser();
            assertEquals(expectedLogin,loginResult);

            //Part 2 

            Task task = new Task("","AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA","","","",0,0,0);//(Farrel,2023)

            Task task1 = new Task("","Create Login to authenticate users","","","",0,0,0);//(Farrel,2023)

            boolean expectedCheckTest1 = true;
            boolean checkResult = task.checkTaskDescrip();
            assertEquals(expectedCheckTest1,checkResult);

            boolean expectedCheckTest2 = false;
            boolean checkResult2 = task1.checkTaskDescrip();
            assertEquals(expectedCheckTest2,checkResult2);

            Task task2 = new Task("Add Login Feature","","","Robyn","",0,0,0);//(Farrel,2023)

            String expectedTaskID = "AD:0:BYN";
            String checkTaskID = task2.createTaskID();
            assertEquals(expectedTaskID,checkTaskID);

            Task task3 = new Task();
            
            Task[] tasks = {
                    new Task("Create Login","","","Mike Smith","To Do",0,5,0),
                    new Task("Create Add Features","","","Edward Harrison","Doing",0,8,0),
                    new Task("Create Reports","","","Samantha Paulson","Done",0,2,0),
                    new Task("Add Arrays","","","Glenda Oberholzer","To Do",0,11,0)
                    };

            for(int a = 0; a < tasks.length; a++){
                int duration = Integer.parseInt(JOptionPane.showInputDialog("Enter duration."));//(Farrel,2023)

                Task task4 = new Task("","","","","",0,duration,0);
                tasks[a] = task4;
            }

            int expectedReturn = 89;

            int checkReturn = task3.returnTotalHours(tasks);
            assertEquals(expectedReturn,checkReturn);    

            //Part 3

                String[] name = {"Mike Smith","Edward Harrington","Samantha Paulson","Glenda Oberholzer"};

                for(int x = 0;x < tasks.length;x++){
                    tasks[x] = new Task("","","",name[x],"",0,0,0);
                }


                poplateArray(tasks);

                for(int x = 0; x < tasks.length;x++){
                    assertEquals(name[x],tasks[x].getDeveloper());
            }  

            //Longest duration test.

                String result = task3.searchLongestDuration(tasks);
                
                String expectedMessage = "Task details: " + "\nTask developer details: " + "Glenda Oberholzer" + "\nTask duration: " + 11;
                assertEquals(expectedMessage,result);
            
            //Search for tasks
            
            String expectedTask = task3.searchTaskName(tasks);
            String expectedOutput  = "Task details: " + "\nTask name: " + "Create Login" + "\nDeveloper details: " + "Mike Smith" + "\nTask Status: " + "To Do";
            assertEquals(expectedOutput,expectedTask);
            
            //Search Developer
            
            String developerOutput = task3.searchDeveloper(tasks);
            String expectedDeveloper = "Task details: " +"\nTask name: " + "Create Reports" + "\nTask Status: " + "Done";
            assertEquals(developerOutput,expectedDeveloper);
            
            //Delete task from array
            
            String deleteOutput = task3.deleteTask(tasks);
            String expectedDelete = "Entry " + "Create Reports" + " successfully deleted.";
            assertEquals(deleteOutput,expectedDelete);
            }  



    public static void poplateArray(Task[] tasks) {
            
        for(int x = 0; x < tasks.length; x++){
            String developer = JOptionPane.showInputDialog("Enter developer name.");
            
            Task task = new Task("","","",developer,"",0,0,0);
            tasks[x] = task;
            }
    }
    public static void capture(Task[] tasks){
        for(int x = 0; x < tasks.length;x++){
            String developer = JOptionPane.showInputDialog("Enter developer name.");
            int duration = Integer.parseInt(JOptionPane.showInputDialog("Enter the duration."));
            
             tasks[x]  = new Task("","","",developer,"",0,duration,0);
             
        }
    }
    
}
