package assignmaenttry2;

import javax.swing.JOptionPane;

public class Task {
    
    private String taskName,taskDescrip,taskId,developer,status;
    private int numberOfTasks,duration,taskNum;
    
    AssignmaentTry2 obj = new AssignmaentTry2();
    
        public Task(){
            taskName = taskDescrip = taskId = status ="";
            numberOfTasks = duration = taskNum;
        }
        public Task(String taskName,String taskDescrip,String taskId,String developer,String status,int numberOfTasks,int duration,int taskNum){
            this.taskName = taskName;
            this.taskDescrip = taskDescrip;
            this.taskId = taskId;
            this.developer = developer;
            this.status = status;
            this.numberOfTasks = numberOfTasks;
            this.duration = duration;
            this.taskNum = taskNum;
        }
        
            public void setTaskName(String t){
                taskName = t;
                }
            public String getTaskName(){
                return taskName;
                }
            public void setTaskDescrip(String t){
                taskDescrip = t;
                }
            public String getTaskDescrip(){
                return taskDescrip;
                }
            public void setTaskID(String t){
                taskId = t;
                }
            public String getTaskId(){
                return createTaskID();
                }
            public void setStatus(String s){
                status = s;
                }
            public String getStatus(){
                return status;
                }
            public void setNumberOfTasks(int n){
                numberOfTasks = n;
                }
            public int getNumberOfTasks(){
                return numberOfTasks;
                }
            public void setDuration(int d){
                duration = d;
                }
            public int getDuration(){
                return duration;
                }
            public void setTaskNum(int t){
                taskNum = t;
                }
            public int getTaskNum(){
                return taskNum;
                }
            public void setDeveloper(String d){
                developer = d;
                }
            public String getDeveloper(){
                return developer;
                }
        
                public String createTaskID(){//(Farrel,2023)
                        
                        if(taskName != null && developer != null){
                            String firstTwo = taskName.substring(0, Math.min(taskName.length(), 2));
                            String lastThree = developer.substring( Math.max(0,developer.length() - 3));

                            taskId = firstTwo.toUpperCase() + ":" + taskNum + ":" + lastThree.toUpperCase();

                         return taskId;
                        }
                        else{
                            return "Task cannot be completed, missing information.";
                        }
                    }
        
            public boolean checkTaskDescrip(){//(Farrel,2023)

                    int count = 0;

                    for(int x = 0; x < taskDescrip.length(); x++){
                        if(!taskDescrip.isBlank()){
                           count++; 
                        }
                    }

                        if(count >= 50){
                            return true;
                        }
                        else{
                            return false;
                        }
                }

    /**
     *
     * @param tasks
     */
            public void printTaskDetails(Task tasks[]){//(Farrel,2023)
                    for(int x = 0; x < numberOfTasks; x++){
                        JOptionPane.showMessageDialog(null,"Task details: " + "\nTask status: " + tasks[x].getStatus()
                                                                            + "\nDeveloper details: " + tasks[x].getDeveloper()
                                                                            + "\nTask Number: " + tasks[x].getTaskNum()
                                                                            + "\nTask Name: " + tasks[x].getTaskName()
                                                                            + "\nTask Description: " + tasks[x].getTaskDescrip()
                                                                            + "\nTask ID: " + tasks[x].getTaskId()
                                                                            + "\nTask Duration: " + tasks[x].getDuration() +" hrs."
                                                                            + "\n\nTotal hours: " + tasks[x].returnTotalHours(tasks) + "hrs");
                    }

                }
            
            public int returnTotalHours(Task tasks[]){//(Farrel,2023)
                int totalHours = 0;

                for(int x = 0; x < tasks.length ;x++){
                    totalHours += tasks[x].getDuration();
                }
                return totalHours;
            }
        
            //Menu for adding, showing report or exsiting the program.
            public void menu(){//(Farrel,2023)
                Task tasks[] = null;
                int choice =  0;

                do{

                    choice = Integer.parseInt(JOptionPane.showInputDialog("Hi, What would you like to do? \n1) Add tasks \n2) Show report \n0) Quit"));

                    switch(choice){

                        case 1:
                            tasks = obj.capture();
                            break;
                        case 2:
                            if (tasks != null && tasks.length > 0) {
                            reportMenu(tasks);
                    } else {
                        JOptionPane.showMessageDialog(null, "No tasks available.");
                    }
                            break;
                        case 0:
                            JOptionPane.showMessageDialog(null,"You are exiting the program, thank you for using the program.");
                            break;
                        default: JOptionPane.showMessageDialog(null,"Invalid input,please try again.");
                    }
                }while(choice != 0);
            }
            
            //Menu that shows how you can display the tasks.
            public void reportMenu(Task tasks[]){//(Farrel,2023)

                int choice =  0;

                do{

                    choice = Integer.parseInt(JOptionPane.showInputDialog("Hi, What would you like to do? \n1) Display details for the task with the longest duration \n2) Show all tasks assigned to a developer. \n3)Delete a task \n4)Dislpay task Report \n5) Search a Task\n0)Leave"));

                    switch(choice){

                        case 1:
                                JOptionPane.showMessageDialog(null,searchLongestDuration(tasks));
                            break;
                        case 2:
                                JOptionPane.showMessageDialog(null,searchDeveloper(tasks));
                            break;
                        case 3:
                                JOptionPane.showMessageDialog(null,deleteTask(tasks));
                            break;
                        case 4:
                                JOptionPane.showMessageDialog(null,displayAllTasks(tasks));
                            break;
                        case 5:
                                JOptionPane.showMessageDialog(null,searchTaskName(tasks));
                        case 0:
                            JOptionPane.showMessageDialog(null,"Leaving report feature.");
                            break;    
                        default: JOptionPane.showMessageDialog(null,"Invalid input,please try again.");
                    }
                }while(choice != 0);
            }
            
            //Determining the task with the longest duration.
            public String searchLongestDuration(Task tasks[]){//(Farrel,2023)

                int max = 0;
                int index = -1;

                    for(int x = 0; x < tasks.length; x++){
                        if(tasks[x].getDuration() > max){
                            max = tasks[x].getDuration();
                            index = x;
                        }
                    }

                    if(index == -1){
                        return "No tasks found.";
                    }
                    else{
                        return "Task details: " + "\nTask developer details: " +  tasks[index].getDeveloper() + "\nTask duration: " + max;
                    }
                }
            
            //Searching tasks by the task name.
            public String searchTaskName(Task tasks[]){//(Farrel,2023)

                int index = -1; 
                do{
                    String searchName = JOptionPane.showInputDialog("Enter the task name.");

                    for(int x = 0; x < tasks.length;x++){
                        if(tasks[x].getTaskName().equals(searchName)){
                            index = x;
                            break;
                        }
                    }
                    if(index == -1)
                        return "Task name not found";
               }while(index == -1);

                return "Task details: " + "\nTask name: " + tasks[index].getTaskName() + "\nDeveloper details: " + tasks[index].getDeveloper() + "\nTask Status: " + tasks[index].getStatus();

                }
            
            //Searching tasks by the developer name.
            public String searchDeveloper(Task tasks[]){//(Farrel,2023)

                int index = -1; 
                do{
                    String searchDeveloper = JOptionPane.showInputDialog("Enter the developer name.");

                    for(int x = 0; x < tasks.length;x++){
                        if(tasks[x].getDeveloper().equals(searchDeveloper)){
                            index = x;
                            break;
                        }
                    }
                    if(index == -1)
                       return "Developer name not found";
               }while(index == -1);

               return "Task details: " + "\nTask name: " + tasks[index].getTaskName() + "\nTask Status: " + tasks[index].getStatus();

            }
            
            //Deleting a specified task.
            public String deleteTask(Task tasks[]){//(Farrel,2023)
                String taskDelete = JOptionPane.showInputDialog("Enter task you would like to delete.");
                
                int index = -1;
                    
                    for(int x = 0; x < tasks.length;x++){
                        if(tasks[x].getTaskName().equals(taskDelete))
                            index = x;
                        break;
                    }
                    
                    if(index != -1){
                        for(int x = 0; x < tasks.length;x++){
                            tasks[x] = tasks[x + 1];
                        }
                    }
                    
                    return "Entry " + taskDelete + " successfully deleted.";
            }
            
            //Displaying details of all the tasks.
            public String displayAllTasks(Task tasks[]){//(Farrel,2023)

                String message = "Array Elements:\n"; 
                    for(int x = 0; x < tasks.length; x++){
                        message += "Task Status: "+tasks[x].getStatus() 
                                +  "\nDeveloper details: " + tasks[x].getDeveloper()
                                + "\nTask Number: " + tasks[x].getTaskNum()
                                + "\nTask Name: " + tasks[x].getTaskName()
                                + "\nTask Description: " + tasks[x].getTaskDescrip()
                                + "\nTask ID: " + tasks[x].getTaskId()
                                + "\nTask Duration: " + tasks[x].getDuration() +" hrs."
                                + "\n\n";
                    }

                    return message;
            }
    

}
