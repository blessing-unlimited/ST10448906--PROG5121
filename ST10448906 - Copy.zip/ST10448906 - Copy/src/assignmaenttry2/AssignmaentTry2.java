package assignmaenttry2;

import javax.swing.JOptionPane;

public class AssignmaentTry2 {

    public static void main(String[] args) {
        
            login2 login = new login2(); //(Farrel,2023)
            Task task = new Task();
                
                
                String name = JOptionPane.showInputDialog("Enter your name.");
                    login.setName(name); //(Farrel,2023)
                String lastName = JOptionPane.showInputDialog("Enter your last name.");    
                    login.setLastName(lastName);

                JOptionPane.showMessageDialog(null, "Welcome " + login.getName() + "," + login.getLastName() + " it's nice to meet you.");    

                login.registerUser();

                JOptionPane.showMessageDialog(null, "Login into your account.");    

                login.returnLoginStatus();

                JOptionPane.showMessageDialog(null,"Welcome to EasyKanBan");

                task.menu();
                
                
    
        }
        public Task[] capture(){ //(Farrel,2023)
            
            Task task = new Task();
            
            int numberOfTasks = Integer.parseInt(JOptionPane.showInputDialog("Enter number of tasks."));
            
            Task tasks[] = new Task[numberOfTasks];
            
            int taskNum = -1;

                for(int x = 0; x < tasks.length; x++){    

                    String taskName;

                    do{
                        taskName = JOptionPane.showInputDialog("Create task name.");
                        
                        if(taskName.isEmpty())
                            JOptionPane.showMessageDialog(null,"Invalid input, try again.");
                    }while(taskName.isEmpty());

                    String developer;
                    do{
                        developer = JOptionPane.showInputDialog("Enter developer name.");
                        
                        if(developer.isEmpty())
                            JOptionPane.showMessageDialog(null,"Invalid input, try again.");
                    }while(developer.isEmpty());

                    String taskDescrip;
                    do{
                        taskDescrip = JOptionPane.showInputDialog("Enter task description(must be less than 50 characters).");
                        
                            if(task.checkTaskDescrip()){
                            JOptionPane.showMessageDialog(null, "Description is greater than 50 characters.");
                            }
                            else{
                                JOptionPane.showMessageDialog(null, "Task succsessfully captured.");
                            }

                    }while(task.checkTaskDescrip());


                    int duration = Integer.parseInt(JOptionPane.showInputDialog("Enter number of time in hours."));
                    
                    int choice =  0;
                    String status = "";
                    do{

                        choice = Integer.parseInt(JOptionPane.showInputDialog("Hi, What is the task status? \n1) To do \n2) Done \n3) Doing"));

                        switch(choice){

                            case 1:
                                status = "To Do";
                                task.setStatus(status);
                                break;
                            case 2:
                                status = "Done";
                                task.setStatus(status);
                                break;
                            case 3:
                                status = "Doing";
                                task.setStatus(status);
                                break;
                            default: JOptionPane.showMessageDialog(null,"Invalid input,please try again.");

                        }
                    }while(choice != 1 && choice != 2 && choice != 3 );

                    JOptionPane.showMessageDialog(null,"Task succesfully captured.");


                    taskNum++;

                    tasks[x] = new Task(taskName,taskDescrip,"",developer,status,0,duration,taskNum);
                }
                return tasks;
            }

        
    
    //Reference list:
    //Farell,  J. 2023. Java programming. 10th Edition. Boston: Cengage.
        
            
    //Stack Overflow. 2017. Nurul, 17 June 2017. [Online].
    //Available at: https://stackoverflow.com/search?q=looping+system+in+a+login+system+in+java
    //[Accessed 7 April 2024].
}

